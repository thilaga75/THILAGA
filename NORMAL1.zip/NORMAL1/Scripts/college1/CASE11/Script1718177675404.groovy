import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.navigateToUrl('https://www.sju.edu.in/')

WebUI.click(findTestObject('Object Repository/Page_St Josephs University, Bengaluru/h1_Welcome to St Josephs University,  Benga_94091c'))

WebUI.click(findTestObject('Object Repository/Page_St Josephs University, Bengaluru/a_Know More'))

WebUI.click(findTestObject('Object Repository/Page_St Josephs University,Bengaluru/img_concat(St Joseph, , s University, 36, L_e44efe'))

WebUI.click(findTestObject('Object Repository/Page_St Josephs University, Bengaluru/a_Staff Login'))

WebUI.switchToWindowTitle('St Josephs University')

WebUI.click(findTestObject('Object Repository/Page_St Josephs University/div_St Josephs University Bengaluru India'))

WebUI.click(findTestObject('Object Repository/Page_St Josephs University/li_Give assignments andassess them online'))

WebUI.click(findTestObject('Object Repository/Page_St Josephs University/li_Online attendancemarking and report generation'))

WebUI.click(findTestObject('Object Repository/Page_St Josephs University/a_Poweredby Linways Technologies Pvt. Ltd'))

WebUI.switchToWindowTitle('Linways AMS: Academic Management System For Higher Education Institutions')

WebUI.click(findTestObject('Object Repository/Page_Linways AMS Academic Management System_fad971/p_Create and manage communities, study mate_1b5745'))

