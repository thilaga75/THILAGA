import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.navigateToUrl('https://www.msuniv.ac.in/')

WebUI.click(findTestObject('Object Repository/Page_Manonmaniam Sundaranar University/a_State Level Eligibility Test (SET) Examin_cce942'))

WebUI.click(findTestObject('Object Repository/Page_Manonmaniam Sundaranar University/img_Contact Us_img-responsive img-fullwidth_baa14b'))

WebUI.click(findTestObject('Object Repository/Page_Manonmaniam Sundaranar University/a_Administration'))

WebUI.click(findTestObject('Object Repository/Page_Manonmaniam Sundaranar University/a_Examinations'))

WebUI.click(findTestObject('Object Repository/Page_Manonmaniam Sundaranar University/a_Examination Remuneration'))

WebUI.click(findTestObject('Object Repository/Page_Manonmaniam Sundaranar University/a_Assessement Outcome Document(AOD)'))

WebUI.click(findTestObject('Object Repository/Page_Manonmaniam Sundaranar University/a_Inflibnet'))

WebUI.click(findTestObject('Object Repository/Page_Manonmaniam Sundaranar University/a_UGC'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UGC, New Delhi, India/p_The University Grants Commission (UGC) wa_e4519d'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UGC, New Delhi, India/p_UGC                                      _eb53f0'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UGC, New Delhi, India/p_Student                                  _592f45'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UGC, New Delhi, India/div_Scholarships'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UGC, New Delhi, India/a_View'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UGC, New Delhi, India/a_Back'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UGC, New Delhi, India/button_Scholarships'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UGC, New Delhi, India/a_View_1'))

WebUI.click(findTestObject('Object Repository/Page_Welcome to UGC, New Delhi, India/div_P.G. Indira Gandhi  Scholarship for Sin_e16dff'))

