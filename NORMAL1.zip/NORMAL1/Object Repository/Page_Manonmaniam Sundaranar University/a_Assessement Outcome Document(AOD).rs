<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Assessement Outcome Document(AOD)</name>
   <tag></tag>
   <elementGuidId>5f4574d4-b85a-4c99-ae9a-2906a33bb6c1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='menuzord-right']/ul/li[9]/div/div/div/ul/li/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.megamenu.none > div.megamenu-row > div.col3 > ul.list-unstyled.list-dashed > li > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Assessement Outcome Document(AOD)&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>c2a4ce52-83ca-4734-bd56-9e58b7b4b5b0</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>msuniv_assessement_outcome_document.php</value>
      <webElementGuid>fa00d030-6aaa-4a62-bc0d-c34ec7c3eb95</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Assessement Outcome Document(AOD)</value>
      <webElementGuid>df9fd344-9274-428b-9248-8754daa08ba9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;menuzord-right&quot;)/ul[@class=&quot;menuzord-menu menuzord-right menuzord-indented scrollable&quot;]/li[9]/div[@class=&quot;megamenu none&quot;]/div[@class=&quot;megamenu-row&quot;]/div[@class=&quot;col3&quot;]/ul[@class=&quot;list-unstyled list-dashed&quot;]/li[1]/a[1]</value>
      <webElementGuid>e9d86468-f98c-4be4-96d7-b6e6dec73b54</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='menuzord-right']/ul/li[9]/div/div/div/ul/li/a</value>
      <webElementGuid>c0d6193f-bcb9-45ff-906e-94d239cad056</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Assessement Outcome Document(AOD)')]</value>
      <webElementGuid>3f1db754-0a6f-40c4-b02d-5b78801e00fe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NAAC'])[1]/following::a[1]</value>
      <webElementGuid>945b7dd1-166c-4e8a-b850-a6b47c16f8ad</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC'])[1]/following::a[2]</value>
      <webElementGuid>9864c56c-393e-4a10-89b9-caea72911255</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Peer Team Visit - Video'])[1]/preceding::a[1]</value>
      <webElementGuid>1b453ff5-a9a1-437f-a7f1-4e7b17b65814</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Re-Accreditation Committee'])[1]/preceding::a[2]</value>
      <webElementGuid>eb6f7f12-0c9b-45c8-a7ba-3c9a59e0097e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Assessement Outcome Document(AOD)']/parent::*</value>
      <webElementGuid>ac34906a-7f4b-4a0c-8fb4-02f287b354a1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'msuniv_assessement_outcome_document.php')]</value>
      <webElementGuid>5d0c3f66-9e6a-44da-85d1-cefb8cadd4a9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[9]/div/div/div/ul/li/a</value>
      <webElementGuid>198ead9b-4517-4736-b8d4-7ab9f55ce1da</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'msuniv_assessement_outcome_document.php' and (text() = ' Assessement Outcome Document(AOD)' or . = ' Assessement Outcome Document(AOD)')]</value>
      <webElementGuid>6a3c36e1-648b-4617-9379-18834cdcace2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
