<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Examination Remuneration</name>
   <tag></tag>
   <elementGuidId>e515c2db-0380-4916-9e83-50065744cd37</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='menuzord-right']/ul/li[5]/div/div/div[3]/ul/li/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Examination Remuneration&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>c2240f20-82e0-45ae-8f7e-32799a15d3f9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>msuniv_exam_renumuration.php</value>
      <webElementGuid>d92ec704-a335-45da-8d1e-5b858c6495a3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Examination Remuneration </value>
      <webElementGuid>443110c6-c5e4-4528-80fe-3321fe6040ea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;menuzord-right&quot;)/ul[@class=&quot;menuzord-menu menuzord-right menuzord-indented scrollable&quot;]/li[5]/div[@class=&quot;megamenu none&quot;]/div[@class=&quot;megamenu-row&quot;]/div[@class=&quot;col3&quot;]/ul[@class=&quot;list-unstyled list-dashed&quot;]/li[1]/a[1]</value>
      <webElementGuid>4122f4bd-14a7-4002-afd3-3204c17a24dc</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='menuzord-right']/ul/li[5]/div/div/div[3]/ul/li/a</value>
      <webElementGuid>a558d870-7649-4b5d-9b63-18676a73c6b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Examination Remuneration')]</value>
      <webElementGuid>f61d4032-8f3c-4c3d-85f7-4636b717ce24</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='E- Sanad'])[1]/following::a[1]</value>
      <webElementGuid>d9a6c863-e868-4eb7-ae49-6b4e3ef2e06a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Certificates/Forms'])[1]/following::a[2]</value>
      <webElementGuid>283fd248-7fa3-4dda-ba3e-13b7d1a3a76d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Examination Fee'])[1]/preceding::a[1]</value>
      <webElementGuid>4c12ff22-344e-4578-bd93-40d81bd5327e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Circular / Announcements'])[1]/preceding::a[2]</value>
      <webElementGuid>4cd07e47-827d-4fd9-8d95-97c21738f9fb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Examination Remuneration']/parent::*</value>
      <webElementGuid>bcd44740-e138-40cd-b5a0-ae11663d3c27</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'msuniv_exam_renumuration.php')]</value>
      <webElementGuid>21d9d3a0-3873-4b3c-b1a3-036c313580bb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/div/div/div[3]/ul/li/a</value>
      <webElementGuid>32fd87ac-8054-459d-8ad9-fe54aef428d9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'msuniv_exam_renumuration.php' and (text() = ' Examination Remuneration ' or . = ' Examination Remuneration ')]</value>
      <webElementGuid>0f041eaf-ce40-46b7-9650-988e44e52e5f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
