<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Student                                  _592f45</name>
   <tag></tag>
   <elementGuidId>70e7e3ed-9fbb-444a-9ab1-36ac9e25f3c6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='pills-profile-tab']/div/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#pills-profile-tab > div.text-center > p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=tab[name=&quot;Student Corner&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>8bfab6dd-af57-4996-ba9e-79e3b223dc74</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                            Student
                                            
                                            Corner
                                        </value>
      <webElementGuid>a1b3692b-cdf1-4258-8512-b104ee508ef8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;pills-profile-tab&quot;)/div[@class=&quot;text-center&quot;]/p[1]</value>
      <webElementGuid>4549256c-6c94-4b53-8cf7-adafc4ed47c9</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//a[@id='pills-profile-tab']/div/p</value>
      <webElementGuid>9af718d1-21ce-4a45-bcac-c7fa7f823f06</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Read More'])[2]/following::p[3]</value>
      <webElementGuid>0c83948c-097f-49ef-9e55-d2e12e3cb5d6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Message from'])[1]/following::p[4]</value>
      <webElementGuid>106f086b-6065-4bc9-b30c-c2afd0fe32f4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='e-Governance'])[1]/preceding::p[4]</value>
      <webElementGuid>85fec360-3808-49c8-9376-2b8cd791f2db</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Student']/parent::*</value>
      <webElementGuid>9869d725-9c0c-452a-9b6e-7814f4de58d6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[3]/a/div/p</value>
      <webElementGuid>268c86a3-bdf2-48a1-aa12-acffffc9c143</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = '
                                            Student
                                            
                                            Corner
                                        ' or . = '
                                            Student
                                            
                                            Corner
                                        ')]</value>
      <webElementGuid>1157e221-31f0-48dd-9ae9-d6661a5ec5d0</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
