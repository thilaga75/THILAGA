<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_The University Grants Commission (UGC) wa_e4519d</name>
   <tag></tag>
   <elementGuidId>97b2bb36-6ff2-485f-a919-6af997fddf2c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='content']/section/div/div/div[2]/div/div/div[2]/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.col-md-9 > p.text-justify</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;The University Grants Commission (UGC) was established by an Act of Parliament i&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>4b0910da-7452-4fb7-b3d7-e0a20f3110e3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>text-justify</value>
      <webElementGuid>023491bc-28a6-4bb6-b8e3-c6d27500c7dd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                        The University Grants Commission (UGC) was established by an Act of Parliament in 1956 to coordinate, determine, and maintain standards of teaching, examination, and research in university education. Now, UGC has become an important pillar of higher education.

                                    </value>
      <webElementGuid>a61f66de-375f-4db7-b40a-7abce6baa96a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;content&quot;)/section[@class=&quot;short-info&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-6&quot;]/div[@class=&quot;text-container aos-init aos-animate&quot;]/div[@class=&quot;text&quot;]/div[@class=&quot;col-md-9&quot;]/p[@class=&quot;text-justify&quot;]</value>
      <webElementGuid>1f545952-e4ea-4c4f-950f-4272d4c5b194</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='content']/section/div/div/div[2]/div/div/div[2]/p</value>
      <webElementGuid>ea2fcbc2-c6a6-4256-9b7c-719d10e10ade</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Message from'])[1]/following::p[1]</value>
      <webElementGuid>317a0c91-6f60-4841-8754-891b45b9c4de</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Read More'])[2]/preceding::p[1]</value>
      <webElementGuid>a4b6bade-25de-4dee-881b-5a45fe3e78a1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='The University Grants Commission (UGC) was established by an Act of Parliament in 1956 to coordinate, determine, and maintain standards of teaching, examination, and research in university education. Now, UGC has become an important pillar of higher education.']/parent::*</value>
      <webElementGuid>dbafe927-999f-41aa-9715-17ee8366b9df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/p</value>
      <webElementGuid>07d4a334-560f-4ec4-a289-d20cf00a31d3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = '
                                        The University Grants Commission (UGC) was established by an Act of Parliament in 1956 to coordinate, determine, and maintain standards of teaching, examination, and research in university education. Now, UGC has become an important pillar of higher education.

                                    ' or . = '
                                        The University Grants Commission (UGC) was established by an Act of Parliament in 1956 to coordinate, determine, and maintain standards of teaching, examination, and research in university education. Now, UGC has become an important pillar of higher education.

                                    ')]</value>
      <webElementGuid>c4fae410-add3-40a7-9f2b-3f798c8ae9e4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
