<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_P.G. Indira Gandhi  Scholarship for Sin_e16dff</name>
   <tag></tag>
   <elementGuidId>5a22808c-eb09-4ab2-98e3-7670203b1d7a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Name of the Scheme:'])[1]/following::div[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.col-md-9.info</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>.row > div:nth-child(2) >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>4a915025-19db-4d57-a198-284e9fc8888b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-md-9 info</value>
      <webElementGuid>bca500c6-e99a-4ee5-b2ef-d8a2fc318815</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-aos</name>
      <type>Main</type>
      <value>fade-up</value>
      <webElementGuid>a80b40af-bb9d-4724-8b50-f822a0f678ba</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-aos-delay</name>
      <type>Main</type>
      <value>100</value>
      <webElementGuid>ebd51c96-7828-45cd-a596-a38962b199b9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                            
                                P.G. Indira Gandhi  Scholarship for Single Girl Child
                            
                        </value>
      <webElementGuid>f75f80e2-e64c-41da-bd6d-080a1639be64</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;single-project&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;project&quot;]/div[@class=&quot;col-sm-12&quot;]/div[@class=&quot;row text-container left-margin&quot;]/div[@class=&quot;col-md-9 info&quot;]</value>
      <webElementGuid>1b9195ed-2117-4319-8d50-834c0c3eff08</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Name of the Scheme:'])[1]/following::div[1]</value>
      <webElementGuid>77e8a5a0-9992-406a-9da7-84eb66c82f84</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Back'])[1]/following::div[3]</value>
      <webElementGuid>6e8de4f2-6b01-47c4-9514-4144eb55d533</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Objective of Scheme:'])[1]/preceding::div[1]</value>
      <webElementGuid>7531ee70-4246-43d6-a839-5ff8ecce7f39</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Eligibility:'])[1]/preceding::div[3]</value>
      <webElementGuid>2ecc5cdf-c4b1-4e36-95d7-3bfa257b8727</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div[2]</value>
      <webElementGuid>c44ce62f-b0ba-487e-9db5-e66fadcdd8e1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                            
                                P.G. Indira Gandhi  Scholarship for Single Girl Child
                            
                        ' or . = '
                            
                                P.G. Indira Gandhi  Scholarship for Single Girl Child
                            
                        ')]</value>
      <webElementGuid>deb54513-08bc-4285-a407-ad396bc61fce</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
