<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Premium education at an affordable fee _d00e53</name>
   <tag></tag>
   <elementGuidId>03ef1407-b25a-480a-97ad-41bc18a3a29e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='ENQUIRE NOW'])[1]/following::div[6]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.trans</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Premium education at an affordable fee ! Embark on your career journey with a he&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>6f01facf-490f-4857-9cc3-5d3fe7fd8783</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>trans</value>
      <webElementGuid>5c859f4f-1371-4e09-a488-b329139dbc96</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>                   
                                Premium education at an affordable fee ! 
                                Embark on your career journey  with a head start
                            </value>
      <webElementGuid>573fd52e-c332-4522-948c-15ee7885f932</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;fa-events-icons-ready&quot;]/body[1]/section[@class=&quot;hero-section pt-10 pt-xs-30 pt-sm-30&quot;]/div[@class=&quot;overlay&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row mt-80&quot;]/div[@class=&quot;col-lg-5&quot;]/div[@class=&quot;trans&quot;]</value>
      <webElementGuid>334a39d3-c9a8-4c8d-8cb5-fde27f295105</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ENQUIRE NOW'])[1]/following::div[6]</value>
      <webElementGuid>a5049fd6-3733-453e-b0cb-cb422a0b683d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='PLACEMENTS'])[1]/following::div[6]</value>
      <webElementGuid>471e9512-705b-46ee-b5aa-36235fc15d8c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/div</value>
      <webElementGuid>61325238-037a-4521-97b5-cb18f6bf473e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '                   
                                Premium education at an affordable fee ! 
                                Embark on your career journey  with a head start
                            ' or . = '                   
                                Premium education at an affordable fee ! 
                                Embark on your career journey  with a head start
                            ')]</value>
      <webElementGuid>acfaf842-02cf-4684-95db-e00cc484c3e5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
