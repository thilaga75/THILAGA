<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_</name>
   <tag></tag>
   <elementGuidId>69378a65-f107-453a-8932-08ad29bc4a6c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='myModal']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#myModal</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#myModal</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>12cde98c-9fbf-4e7a-80fc-870b6319e150</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>myModal</value>
      <webElementGuid>c5187707-6690-4ca0-b985-79e3a847e446</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>modal</value>
      <webElementGuid>a7a01c4c-4e65-4de0-9529-e476a17f6674</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
        ×
        
    
</value>
      <webElementGuid>bdd76097-2b7d-471e-81f9-32614786bd2a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;myModal&quot;)</value>
      <webElementGuid>a3df8dea-1710-4d8c-a5ad-73a478a25057</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//div[@id='myModal']</value>
      <webElementGuid>4a60caac-12c6-4e63-a415-c39534cc026f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='code-component-47B61EE2-A746-4E71-90E9-7C379E3C1751']/div</value>
      <webElementGuid>ca1e2d90-c4d4-4dab-a04a-987344ea2d20</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Obituaries'])[2]/following::div[88]</value>
      <webElementGuid>4712d53d-f263-4eda-91f6-ffa8f9244be4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='TDS 2023-24'])[2]/following::div[89]</value>
      <webElementGuid>d02d106e-87ad-4274-af60-5765fab90cbc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ANNOUNCEMENTS'])[1]/preceding::div[83]</value>
      <webElementGuid>45f87131-8abf-4b8d-97ea-bba8e8b84e3e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div/div/div/div/div/div/div/div/div/div[2]/div/div/div/div</value>
      <webElementGuid>c79bfd48-2a90-4ac7-a87b-2db053d54ad1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[@id = 'myModal' and (text() = '
    
        ×
        
    
' or . = '
    
        ×
        
    
')]</value>
      <webElementGuid>a076c6b4-cce0-4eb9-b20b-77e564df9bcd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
