<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Time Table</name>
   <tag></tag>
   <elementGuidId>2c0bbd99-3880-4a8a-a9a2-cd292062cd3a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Senior College'])[3]/following::span[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.level-1.hover > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Time Table&quot;s]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>7640c598-ad4a-49e1-bebb-23a8be3c9712</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Time Table</value>
      <webElementGuid>c8b63740-ab04-4c6a-8bcc-f710295ebbaa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;Preview_body__2wDzb bodyBackground desktopV effects&quot;]/div[@class=&quot;menu moreEnabled menuself menuhorizontal dropdown menuhorizontalcenter menuverticalmiddle Accented jsdropdown&quot;]/ul[@class=&quot;ThemeMenu2&quot;]/li[@class=&quot;hover&quot;]/ul[@class=&quot;ThemeMenu2&quot;]/li[@class=&quot;menuhidden&quot;]/a[@class=&quot;level-1 hover&quot;]/span[1]</value>
      <webElementGuid>f12065f7-a388-41fd-8766-c77e5542bd81</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Senior College'])[3]/following::span[1]</value>
      <webElementGuid>976c643c-4001-419f-8b16-a4fd8f0ad14b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Junior College'])[5]/following::span[2]</value>
      <webElementGuid>2153efac-002f-4175-b7e2-f1a2c63e62d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Wellness Centre'])[3]/preceding::span[1]</value>
      <webElementGuid>4eb18656-7688-404d-82c0-64c2a825f554</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Library OPAC'])[3]/preceding::span[2]</value>
      <webElementGuid>dca34f71-d653-4481-a352-f5ce28acc209</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/ul/li/ul/li[2]/a/span</value>
      <webElementGuid>7cdaf248-825b-4d52-8d6b-65a7181428ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Time Table' or . = 'Time Table')]</value>
      <webElementGuid>4ba41296-87bd-4a83-acc6-21396678aec1</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
