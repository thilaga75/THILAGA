<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_BA-MCJ</name>
   <tag></tag>
   <elementGuidId>13e8326d-0679-44bd-9222-c4a3adb94f80</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='BAF'])[3]/following::span[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.level-3.hover > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;BA-MCJ&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>89af835b-063d-448f-afbf-dec292dcad26</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>BA-MCJ</value>
      <webElementGuid>badc6b18-5b84-4139-858b-ff460decd941</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;Preview_body__2wDzb bodyBackground desktopV effects&quot;]/div[@class=&quot;menu moreEnabled menuself menuhorizontal dropdown menuhorizontalcenter menuverticalmiddle Accented jsdropdown&quot;]/ul[@class=&quot;ThemeMenu2&quot;]/li[@class=&quot;hover&quot;]/ul[@class=&quot;ThemeMenu2&quot;]/li[@class=&quot;menuhidden&quot;]/ul[@class=&quot;ThemeMenu2&quot;]/li[@class=&quot;menuhidden&quot;]/ul[@class=&quot;ThemeMenu2&quot;]/li[@class=&quot;menuhidden&quot;]/a[@class=&quot;level-3 hover&quot;]/span[1]</value>
      <webElementGuid>03243bf2-dff0-4ffd-baa9-f52b26e476a5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='BAF'])[3]/following::span[1]</value>
      <webElementGuid>422e77ea-05b7-42f9-ab27-4783cb4d845f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='BA'])[3]/following::span[2]</value>
      <webElementGuid>aef58fa9-5016-4a55-9ed4-7a645571ee7a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='BCom'])[3]/preceding::span[1]</value>
      <webElementGuid>59048fc9-778b-4a09-aac7-ca7865650273</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='BSc'])[3]/preceding::span[2]</value>
      <webElementGuid>0c61e93e-dc7a-437d-9bad-c1fd47d1adf4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[5]/ul/li/ul/li/ul/li/ul/li[3]/a/span</value>
      <webElementGuid>f3e858b8-9d12-4a8e-bb4a-1b2862be77e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'BA-MCJ' or . = 'BA-MCJ')]</value>
      <webElementGuid>e6ce3b07-7b67-4d59-80e5-4108434d268e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
