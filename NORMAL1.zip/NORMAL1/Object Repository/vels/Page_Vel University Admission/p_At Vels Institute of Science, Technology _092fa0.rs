<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_At Vels Institute of Science, Technology _092fa0</name>
   <tag></tag>
   <elementGuidId>aea79bc6-f3df-4eed-81db-3fc752447d39</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='why']/div/div/div[2]/div[3]/p[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>p.smalltext</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;At Vels Institute of Science, Technology &amp; Advanced Studies (VISTAS), we offer p&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>caee3838-5e81-4698-82e1-e26e151ce095</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>smalltext</value>
      <webElementGuid>8bc1f6e1-1682-408a-b6c9-166761064f2b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>At Vels Institute of Science, Technology &amp; Advanced Studies (VISTAS),
                                we offer premium education at an affordable fee. Our state-of-the-art facilities and
                                highly qualified faculty provide an ideal learning environment. Our global exchange
                                programs give our students a global perspective, and our dedicated placement cell
                                ensures successful career prospects. Join our community of passionate learners and
                                educators, and unlock your full potential with VISTAS.</value>
      <webElementGuid>ab91dd79-70ba-459c-8152-c6dd01b0cccd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;why&quot;)/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-12&quot;]/div[@class=&quot;d-flex flex-lg-row flex-sm-column flex-md-row flex-column&quot;]/div[@class=&quot;posrelat txt&quot;]/p[@class=&quot;smalltext&quot;]</value>
      <webElementGuid>e0485739-fc11-4bc5-a9d4-d097136170f0</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='why']/div/div/div[2]/div[3]/p[2]</value>
      <webElementGuid>074a7838-6baf-4e8a-93b9-474d8de8c13b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='APPLY NOW'])[11]/following::p[7]</value>
      <webElementGuid>9af534aa-ff34-44b4-a3e8-4165e4b7ecbf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='LL.M Law Relating to Intellectual Property Rights'])[1]/following::p[8]</value>
      <webElementGuid>fcaa9f0e-6dfc-453f-9984-1011fea64cd4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Our Top Recruiters'])[1]/preceding::p[1]</value>
      <webElementGuid>05cc8efd-c6a9-43af-b660-2e431ea99303</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Previous'])[1]/preceding::p[1]</value>
      <webElementGuid>85161f98-3e36-4a0f-abc9-23c183e9c990</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/p[2]</value>
      <webElementGuid>479f0a98-993c-48f5-9ab8-f5bb2fcaefa9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'At Vels Institute of Science, Technology &amp; Advanced Studies (VISTAS),
                                we offer premium education at an affordable fee. Our state-of-the-art facilities and
                                highly qualified faculty provide an ideal learning environment. Our global exchange
                                programs give our students a global perspective, and our dedicated placement cell
                                ensures successful career prospects. Join our community of passionate learners and
                                educators, and unlock your full potential with VISTAS.' or . = 'At Vels Institute of Science, Technology &amp; Advanced Studies (VISTAS),
                                we offer premium education at an affordable fee. Our state-of-the-art facilities and
                                highly qualified faculty provide an ideal learning environment. Our global exchange
                                programs give our students a global perspective, and our dedicated placement cell
                                ensures successful career prospects. Join our community of passionate learners and
                                educators, and unlock your full potential with VISTAS.')]</value>
      <webElementGuid>5c73336f-25e5-4bf6-b733-4bdb7423007e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
