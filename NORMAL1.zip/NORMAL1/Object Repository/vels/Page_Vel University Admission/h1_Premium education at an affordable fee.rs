<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h1_Premium education at an affordable fee</name>
   <tag></tag>
   <elementGuidId>15978623-dad1-4031-bab9-7a2d9392a8b4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='ENQUIRE NOW'])[1]/following::h1[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>h1</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;Premium education at an affordable fee !&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h1</value>
      <webElementGuid>fbd796c7-fb7a-4622-a489-96d6cb0a6f36</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Premium education at an affordable fee !</value>
      <webElementGuid>df88004c-ea44-4fde-b1fd-20069a10cf89</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;fa-events-icons-ready&quot;]/body[1]/section[@class=&quot;hero-section pt-10 pt-xs-30 pt-sm-30&quot;]/div[@class=&quot;overlay&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row mt-80&quot;]/div[@class=&quot;col-lg-5&quot;]/div[@class=&quot;trans&quot;]/h1[1]</value>
      <webElementGuid>1cf084a3-e2df-4a75-8333-f8e4928e62df</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ENQUIRE NOW'])[1]/following::h1[1]</value>
      <webElementGuid>b902b4a0-f99e-4c5d-b732-895cb283d676</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='PLACEMENTS'])[1]/following::h1[1]</value>
      <webElementGuid>09db57ce-e8ac-4993-b8d2-2c7183f147a6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Registrations 2024'])[1]/preceding::h1[1]</value>
      <webElementGuid>fe34b688-9eb1-4d3f-9dc0-fef14c54c542</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Premium education at']/parent::*</value>
      <webElementGuid>090b8e42-75dd-4ee5-a344-4fe783422573</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//h1</value>
      <webElementGuid>7da6383f-9e14-4b6a-90fd-6bb7bc380bbf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//h1[(text() = 'Premium education at an affordable fee !' or . = 'Premium education at an affordable fee !')]</value>
      <webElementGuid>a3c8977d-aa4c-4f26-8a7b-272d53a38920</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
