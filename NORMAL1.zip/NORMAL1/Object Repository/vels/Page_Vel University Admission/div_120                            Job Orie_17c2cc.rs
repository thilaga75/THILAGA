<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_120                            Job Orie_17c2cc</name>
   <tag></tag>
   <elementGuidId>a243446c-2277-44b4-8e44-63d166f0abc4</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Please Wait...'])[1]/following::div[12]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;120+ Job Oriented Courses&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>20d93b98-0af1-431e-a7fc-57a04f80850e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>couterbx </value>
      <webElementGuid>c3033265-b931-41f2-9326-3902673d6c35</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                            120+
                            Job Oriented Courses
                        </value>
      <webElementGuid>04217a08-775e-4ca7-a66b-4378e6fccc27</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[@class=&quot;fa-events-icons-ready&quot;]/body[1]/div[@class=&quot;counter-wrp hero-logo&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;counterrw&quot;]/div[@class=&quot;row d-padd&quot;]/div[@class=&quot;col-lg-3 col-sm-12 col-md-12 text-center&quot;]/div[@class=&quot;couterbx&quot;]</value>
      <webElementGuid>793197c2-cee0-4c82-96ad-2d9e93167ce2</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Please Wait...'])[1]/following::div[12]</value>
      <webElementGuid>972abc11-64ee-4b59-ab6b-bdaa7cc3af73</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/div/div[2]/div</value>
      <webElementGuid>0ae85ed5-bcfe-4d93-a632-59016ea9fca3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                            120+
                            Job Oriented Courses
                        ' or . = '
                            120+
                            Job Oriented Courses
                        ')]</value>
      <webElementGuid>90a95b88-bd29-448c-992a-f2dc4bce254b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
