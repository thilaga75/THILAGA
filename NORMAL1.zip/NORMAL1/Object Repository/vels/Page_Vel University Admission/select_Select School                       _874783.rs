<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Select School                       _874783</name>
   <tag></tag>
   <elementGuidId>d28c0f53-f239-4a40-9a74-8e1cfddfc11b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='cmbApplicationCategory']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#cmbApplicationCategory</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>#cmbApplicationCategory</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>e0996657-cb31-4e9f-ae8c-846b2b7967da</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
      <webElementGuid>c67535fa-fd56-4710-8752-11a2bb6f7282</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>cmbApplicationCategory</value>
      <webElementGuid>528029d8-c27d-4e99-b5ed-7bfc9e0317d1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>cmbApplicationCategory</value>
      <webElementGuid>2ed6efaa-df52-4b07-93c7-668e0e2a65ff</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>onchange</name>
      <type>Main</type>
      <value>funChangeApplCategory()</value>
      <webElementGuid>1d0ea561-f238-4219-b756-2aa089c68b1e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> 
                                                    Select School
                                                    
                                                        School of Allied Health Sciences
                                                    
                                                        School of Engineering &amp; Technology
                                                    
                                                        School of Legal Studies
                                                    
                                                        School of Life Sciences
                                                    
                                                        School of Management Studies &amp; Commerce
                                                    
                                                        School of Maritime Studies
                                                    
                                                        School of Pharmaceutical Sciences
                                                    
                                                        School of Physiotherapy
                                                    
                                                        School of Research and Development
                                                    
                                                        School of Science &amp; Humanities
                                                     
                                                </value>
      <webElementGuid>c4a9c737-c9d3-40fd-b23e-f7684346353d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;cmbApplicationCategory&quot;)</value>
      <webElementGuid>e3bc6d9f-9af5-44ec-92d1-34087fd7434d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='cmbApplicationCategory']</value>
      <webElementGuid>448af053-6712-4f40-95d6-abbee6495ec8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='frmApplicantRegistration']/div[11]/div/select</value>
      <webElementGuid>33e0d195-9143-455a-8aeb-df5ec7ed833c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='School'])[1]/following::select[1]</value>
      <webElementGuid>d1ad844f-c2d4-40f0-85cd-df23d85b8d58</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Email'])[1]/following::select[1]</value>
      <webElementGuid>2ea97652-a9e8-43fd-b55c-86caa522d9ee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Campus'])[1]/preceding::select[1]</value>
      <webElementGuid>ba6b4dbd-7cef-4b96-8c84-49d9a4c266de</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Program'])[1]/preceding::select[2]</value>
      <webElementGuid>32910de7-70ad-4530-a849-96f924c183d4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>49d717a6-8a55-4ad2-8dbf-e68247bfb3a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'cmbApplicationCategory' and @id = 'cmbApplicationCategory' and (text() = ' 
                                                    Select School
                                                    
                                                        School of Allied Health Sciences
                                                    
                                                        School of Engineering &amp; Technology
                                                    
                                                        School of Legal Studies
                                                    
                                                        School of Life Sciences
                                                    
                                                        School of Management Studies &amp; Commerce
                                                    
                                                        School of Maritime Studies
                                                    
                                                        School of Pharmaceutical Sciences
                                                    
                                                        School of Physiotherapy
                                                    
                                                        School of Research and Development
                                                    
                                                        School of Science &amp; Humanities
                                                     
                                                ' or . = ' 
                                                    Select School
                                                    
                                                        School of Allied Health Sciences
                                                    
                                                        School of Engineering &amp; Technology
                                                    
                                                        School of Legal Studies
                                                    
                                                        School of Life Sciences
                                                    
                                                        School of Management Studies &amp; Commerce
                                                    
                                                        School of Maritime Studies
                                                    
                                                        School of Pharmaceutical Sciences
                                                    
                                                        School of Physiotherapy
                                                    
                                                        School of Research and Development
                                                    
                                                        School of Science &amp; Humanities
                                                     
                                                ')]</value>
      <webElementGuid>271af2cb-0106-428b-a201-c6cb297c87d3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
