<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Give assignments andassess them online</name>
   <tag></tag>
   <elementGuidId>b3b45602-689f-4ab7-8e6d-8f005a8dcebc</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Teacher Benefits'])[1]/following::li[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Give assignments and assess them online.&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>e2632ef8-f54b-4755-a5d0-a9facf9e892a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Give assignments and
assess them online.
</value>
      <webElementGuid>87fb2460-ed50-4b0e-b6e5-3fca43b97398</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/form[1]/div[@class=&quot;container-fluid login&quot;]/div[@class=&quot;row login-form-mobile&quot;]/div[@class=&quot;col-md-5 col-md-offset-2 col-sm-6 col-sm-offset-1 col-xs-12 hidden-xs&quot;]/ul[@class=&quot;list-unstyled staff-benefits&quot;]/li[2]</value>
      <webElementGuid>c54181fe-9709-4390-8af9-cf85dd4726fa</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Teacher Benefits'])[1]/following::li[2]</value>
      <webElementGuid>2646f128-119b-4e54-9ee5-67099139c687</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]</value>
      <webElementGuid>f263dda3-8a67-41d9-9669-24237b57c522</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = 'Give assignments and
assess them online.
' or . = 'Give assignments and
assess them online.
')]</value>
      <webElementGuid>83e9f6da-ea4d-4a17-a467-d4958439b436</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
