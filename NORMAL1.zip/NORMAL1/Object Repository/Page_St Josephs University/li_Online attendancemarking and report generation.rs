<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Online attendancemarking and report generation</name>
   <tag></tag>
   <elementGuidId>8b3724af-1fb9-4a2e-88c7-d9be5f2d361c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Faculty Login'])[1]/preceding::li[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(6)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Online attendance marking and report generation.&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
      <webElementGuid>d77893ac-c7b3-4458-ae50-159ea1f4bd2f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Online attendance
marking and report generation.
</value>
      <webElementGuid>14959a83-743c-4009-b773-b6b2e3fd0fc8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/form[1]/div[@class=&quot;container-fluid login&quot;]/div[@class=&quot;row login-form-mobile&quot;]/div[@class=&quot;col-md-5 col-md-offset-2 col-sm-6 col-sm-offset-1 col-xs-12 hidden-xs&quot;]/ul[@class=&quot;list-unstyled staff-benefits&quot;]/li[6]</value>
      <webElementGuid>f4a23e40-4c07-4a46-9e8a-ce1a8ceb930d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Faculty Login'])[1]/preceding::li[1]</value>
      <webElementGuid>23fb719a-b25f-4dae-a10c-6d004c15e89c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign In'])[1]/preceding::li[1]</value>
      <webElementGuid>7d30d6a8-1537-4e60-9d97-923d2e15d942</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[6]</value>
      <webElementGuid>6f106a8e-f903-4174-a979-cf5dc8192348</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//li[(text() = 'Online attendance
marking and report generation.
' or . = 'Online attendance
marking and report generation.
')]</value>
      <webElementGuid>c4cd9815-ae91-46e5-bb4c-1e9350d990b2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
