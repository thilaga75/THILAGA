<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_St Josephs University Bengaluru India</name>
   <tag></tag>
   <elementGuidId>bfc72501-9874-4cd8-8f05-68dc5b66e938</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Teacher Benefits'])[1]/preceding::div[8]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.col-md-4.college_title</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;St Josephs University Bengaluru India&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>4445d4da-c2ce-485d-a673-3c81c4f8e0ef</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-md-4 college_title</value>
      <webElementGuid>bfbce6cf-17f8-4fab-90bb-eac6135e7a5e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> St Josephs University Bengaluru India
</value>
      <webElementGuid>2310d1a8-5bab-4ab0-b824-1fde14365509</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;row main-header&quot;]/div[@class=&quot;col-md-4 college_title&quot;]</value>
      <webElementGuid>a4f17a31-1cf0-42e3-ab65-ae6e3f1d3751</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Teacher Benefits'])[1]/preceding::div[8]</value>
      <webElementGuid>f9d47b4a-32e3-45c9-b159-17b0e3db7585</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='St Josephs University Bengaluru India']/parent::*</value>
      <webElementGuid>b166e269-5e61-4337-afe8-f15fdabf0b51</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div</value>
      <webElementGuid>7bc19ed7-59e8-47ed-a7a7-62dd77c54c56</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = ' St Josephs University Bengaluru India
' or . = ' St Josephs University Bengaluru India
')]</value>
      <webElementGuid>e567092c-fc9e-46cb-a3ac-af51f43d8eee</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
