<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_B.A. M.C.J</name>
   <tag></tag>
   <elementGuidId>115c5d4c-5074-42cf-b389-7c02f760c689</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='BAMCJ']/div/div/div/div/div/div/div/div/div/div/div/h1/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#BAMCJ > div.StripPreview_backgroundComponent__3YmQM.Background_backgroundComponent__3_1Ea.hasChildren > div.Preview_column__1KeVx.col > div.Preview_row__3Fkye.row > div.Preview_componentWrapper__2i4QI > div.Preview_block__16Zmu > div.BackgroundPreview_backgroundComponent__3Dr5e.BackgroundPreview_bgHeight__3dD2e.hasChildren > div.Preview_column__1KeVx.col > div.Preview_row__3Fkye.row > div.Preview_componentWrapper__2i4QI > div.Preview_component__SbiKo.text-align-null > div.styles_contentContainer__lrPIa.textnormal.styles_text__3jGMu.styles_invalidateHighlightAndShadows__2W3IH.White.themeTextClass > h1.textheading1.mobile-oversized > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=heading[name=&quot;B.A. M.C.J.&quot;i] >> span</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>1cf8639e-cc23-4e6a-a2a3-3ce3dc3bc485</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>B.A. M.C.J.</value>
      <webElementGuid>58aed693-0d1a-4c5d-b778-a9b4db89721e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;BAMCJ&quot;)/div[@class=&quot;StripPreview_backgroundComponent__3YmQM Background_backgroundComponent__3_1Ea hasChildren&quot;]/div[@class=&quot;Preview_column__1KeVx col&quot;]/div[@class=&quot;Preview_row__3Fkye row&quot;]/div[@class=&quot;Preview_componentWrapper__2i4QI&quot;]/div[@class=&quot;Preview_block__16Zmu&quot;]/div[@class=&quot;BackgroundPreview_backgroundComponent__3Dr5e BackgroundPreview_bgHeight__3dD2e hasChildren&quot;]/div[@class=&quot;Preview_column__1KeVx col&quot;]/div[@class=&quot;Preview_row__3Fkye row&quot;]/div[@class=&quot;Preview_componentWrapper__2i4QI&quot;]/div[@class=&quot;Preview_component__SbiKo text-align-null&quot;]/div[@class=&quot;styles_contentContainer__lrPIa textnormal styles_text__3jGMu styles_invalidateHighlightAndShadows__2W3IH White themeTextClass&quot;]/h1[@class=&quot;textheading1 mobile-oversized&quot;]/span[1]</value>
      <webElementGuid>04234cdf-e508-49ce-860b-0f4f9aff2b48</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='BAMCJ']/div/div/div/div/div/div/div/div/div/div/div/h1/span</value>
      <webElementGuid>0907eb6c-4d27-4a12-b218-e7ab16eb5b31</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='S.Y. B.Sc. I.T.'])[1]/following::span[1]</value>
      <webElementGuid>70680bc7-6923-44f3-b84c-ec01944f2d41</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='T.Y. BSc. I.T.'])[1]/following::span[2]</value>
      <webElementGuid>b61ab1d1-8bf2-494e-bf8d-588aa0f85d27</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='F.Y. B.A. M.C.J (DIV. A)'])[1]/preceding::span[1]</value>
      <webElementGuid>26919b88-b3f9-4eba-91c1-c9fde104233f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='S.Y. B.A. M.C.J (DIV. A)'])[1]/preceding::span[2]</value>
      <webElementGuid>f9df9d13-c37e-4256-963a-6b5c8aabf899</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[7]/div/div/div/div/div/div/div/div/div/div/div/div/div/h1/span</value>
      <webElementGuid>51cf00ab-9953-4640-8226-17850072727e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'B.A. M.C.J.' or . = 'B.A. M.C.J.')]</value>
      <webElementGuid>0f784d80-4f16-43bb-8255-3b957675835a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
