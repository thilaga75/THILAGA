<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_COURSES  ADMISSION</name>
   <tag></tag>
   <elementGuidId>3c802104-8fab-430a-a195-6dad7391ff50</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='TemplateStrip1']/div/div/div/div/div/div/ul/li[2]/a/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.expandable.level-0.expanded.hover > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;COURSES &amp; ADMISSION &quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>04a7642f-cd81-42fd-bb37-d8126ea3fc44</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>COURSES &amp; ADMISSION</value>
      <webElementGuid>0d025c18-bb7a-40b2-955a-ccea528305b3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;TemplateStrip1&quot;)/div[@class=&quot;StripPreview_backgroundComponent__3YmQM Background_backgroundComponent__3_1Ea hasChildren&quot;]/div[@class=&quot;Preview_column__1KeVx col&quot;]/div[@class=&quot;Preview_row__3Fkye row&quot;]/div[@class=&quot;Preview_componentWrapper__2i4QI&quot;]/div[@class=&quot;Preview_mobileHide__9T929 Preview_component__SbiKo&quot;]/div[@class=&quot;menu moreEnabled menuself menuhorizontal dropdown menuhorizontalcenter menuverticalmiddle Accented&quot;]/ul[@class=&quot;ThemeMenu2&quot;]/li[2]/a[@class=&quot;expandable level-0 expanded hover&quot;]/span[1]</value>
      <webElementGuid>259f3642-aea1-4425-96e6-cc9b9d0394ec</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='TemplateStrip1']/div/div/div/div/div/div/ul/li[2]/a/span</value>
      <webElementGuid>e7c32f11-96a0-4bae-a53d-0b4504922be9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='College Handbook 2023-24'])[2]/following::span[1]</value>
      <webElementGuid>c4d1a6a7-6d4f-448f-99ce-04a2f29568af</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='HEI INFORMATION'])[2]/following::span[2]</value>
      <webElementGuid>8c662293-f822-4d1e-9004-5e90eeb9cf32</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Degree'])[2]/preceding::span[1]</value>
      <webElementGuid>93f16123-a60d-4980-9fe5-4456fd176f57</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='UNDER GRADUATE'])[2]/preceding::span[2]</value>
      <webElementGuid>173fc171-2286-4d4e-a5fd-98e2b1996238</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[2]/a/span</value>
      <webElementGuid>e70b12ec-e46a-4d4a-97a5-3804c69dcd83</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'COURSES &amp; ADMISSION' or . = 'COURSES &amp; ADMISSION')]</value>
      <webElementGuid>dda78828-aca6-4ed0-8d03-e3cb68f3f061</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
