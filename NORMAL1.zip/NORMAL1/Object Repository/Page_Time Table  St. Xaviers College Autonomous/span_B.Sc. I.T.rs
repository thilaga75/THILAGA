<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_B.Sc. I.T</name>
   <tag></tag>
   <elementGuidId>3415a26d-0416-482e-8cdd-0610594f8202</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Section3']/div/div/div/div/div/div/div/div/div[3]/div/div/div/div/a/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.Preview_column__1KeVx.col.isExpandable > div.Preview_componentWrapper__2i4QI > div.Preview_component__SbiKo.align-center > div.ButtonPreview_container__22hQi.ButtonPreview_buttonTransition__CKIAx.button1.White.primary.themeButtonClass > div.ButtonPreview_buttonComponent__17NP0 > a.ButtonPreview_textContainer__t8q7_ > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;B.Sc. I.T.&quot;s]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>c7169c6c-dd72-4538-b9ad-29bf09e28ef7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>B.Sc. I.T.</value>
      <webElementGuid>dce9efa5-598b-435e-8b97-ca3dbc57574d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Section3&quot;)/div[@class=&quot;StripPreview_backgroundComponent__3YmQM Background_backgroundComponent__3_1Ea hasChildren&quot;]/div[@class=&quot;Preview_column__1KeVx col&quot;]/div[@class=&quot;Preview_row__3Fkye row&quot;]/div[@class=&quot;Preview_componentWrapper__2i4QI&quot;]/div[@class=&quot;Preview_block__16Zmu&quot;]/div[@class=&quot;BackgroundPreview_backgroundComponent__3Dr5e BackgroundPreview_bgHeight__3dD2e hasChildren&quot;]/div[@class=&quot;Preview_column__1KeVx col&quot;]/div[@class=&quot;Preview_row__3Fkye row&quot;]/div[@class=&quot;Preview_column__1KeVx col isExpandable&quot;]/div[@class=&quot;Preview_componentWrapper__2i4QI&quot;]/div[@class=&quot;Preview_component__SbiKo align-center&quot;]/div[@class=&quot;ButtonPreview_container__22hQi ButtonPreview_buttonTransition__CKIAx button1 White primary themeButtonClass&quot;]/div[@class=&quot;ButtonPreview_buttonComponent__17NP0&quot;]/a[@class=&quot;ButtonPreview_textContainer__t8q7_&quot;]/span[1]</value>
      <webElementGuid>75593c90-c804-4721-ab1f-10ce82cbd049</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Section3']/div/div/div/div/div/div/div/div/div[3]/div/div/div/div/a/span</value>
      <webElementGuid>6aee0459-22de-47f0-97bc-a67afe716f56</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='B.Com'])[1]/following::span[1]</value>
      <webElementGuid>8fa265b5-8b3f-45b9-81c9-49547878ddd0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='B.Sc.'])[1]/following::span[2]</value>
      <webElementGuid>bd3b56e0-2a8a-4b3d-92ad-3b0d07055b89</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='B.A. M.C.J.'])[1]/preceding::span[1]</value>
      <webElementGuid>1436cde1-c668-4eb8-9ae7-a9fef42d98ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='B.M.S'])[1]/preceding::span[2]</value>
      <webElementGuid>0816803e-9985-4efb-954d-a53d4c77e97f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='B.Sc. I.T.']/parent::*</value>
      <webElementGuid>3c37329b-01c9-4804-9bc4-a16ba473beb8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/div/div/a/span</value>
      <webElementGuid>5df60325-8b77-40fe-a357-51de26cfcf71</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'B.Sc. I.T.' or . = 'B.Sc. I.T.')]</value>
      <webElementGuid>e83d935e-eddb-41b0-8c32-5b58d2d5155e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
