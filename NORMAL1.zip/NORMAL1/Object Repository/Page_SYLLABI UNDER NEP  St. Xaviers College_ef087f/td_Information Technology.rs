<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_Information Technology</name>
   <tag></tag>
   <elementGuidId>f6078934-8c1b-4ddf-a6b6-989da4206b68</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//table[@id='dataTable']/tbody/tr[60]/td[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(60) > td:nth-of-type(2)</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=row[name=&quot;B.Sc. I.T. Information Technology SEC 1 &amp; 2&quot;i] >> internal:role=cell >> nth=1</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>edb0fcfa-de05-4999-9175-f02a5d89a7c9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Information Technology</value>
      <webElementGuid>99013fde-0f47-47d5-9601-007a4531008f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;dataTable&quot;)/tbody[1]/tr[60]/td[2]</value>
      <webElementGuid>29426b2a-060f-4991-9972-695c10588d96</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//table[@id='dataTable']/tbody/tr[60]/td[2]</value>
      <webElementGuid>cf5a1334-f2f0-48a1-b936-c06771b79624</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='B.Sc. I.T.'])[7]/following::td[1]</value>
      <webElementGuid>28d9057d-e92f-412b-bb35-83e9c452a007</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='OE'])[19]/following::td[3]</value>
      <webElementGuid>9c4e4609-0526-4ed1-8e1a-13b4ba527aae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SEC'])[7]/preceding::td[1]</value>
      <webElementGuid>f5ef1f92-ce3a-40ba-9461-fdc74f0b33a4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[60]/td[2]</value>
      <webElementGuid>395b9d93-67ec-4e33-bdc3-b821a865bf66</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = 'Information Technology' or . = 'Information Technology')]</value>
      <webElementGuid>7d99d292-de3e-4919-9966-dc4471fc1ed2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
