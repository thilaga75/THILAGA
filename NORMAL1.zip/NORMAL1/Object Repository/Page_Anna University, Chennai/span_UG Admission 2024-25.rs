<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_UG Admission 2024-25</name>
   <tag></tag>
   <elementGuidId>9827caef-6243-4d8c-8d76-c81945290c68</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//body[@id='bg']/div/header/div/div/div[2]/button[5]/a/b/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>b > span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;UG Admission 2024-25 B.E.(Training Integrated)&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>c649efaf-4831-44c1-a879-d30ed55e8eaf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>UG Admission 2024-25</value>
      <webElementGuid>4a08e5d9-cca5-4c93-a7d2-0d5887cb096e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;bg&quot;)/div[@class=&quot;page-wraper&quot;]/header[@class=&quot;site-header mo-left header&quot;]/div[@class=&quot;sticky-header main-bar-wraper navbar-expand-lg&quot;]/div[@class=&quot;main-bar clearfix&quot;]/div[@class=&quot;mt-3&quot;]/button[@class=&quot;btn&quot;]/a[1]/b[1]/span[1]</value>
      <webElementGuid>a483f469-377b-4167-a151-2fb58539ff0f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//body[@id='bg']/div/header/div/div/div[2]/button[5]/a/b/span</value>
      <webElementGuid>4c4dc2af-6765-4814-b030-58ccf31e6457</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CEAP 2024(M.E./M.Tech./M.Arch./M.Plan.)'])[1]/following::span[1]</value>
      <webElementGuid>8d3f2224-aab9-47aa-a5bf-a631d20c2c15</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='B.E.(Training Integrated)'])[1]/preceding::span[1]</value>
      <webElementGuid>612e58d2-939e-4257-bd81-280bad013ff3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='PG Admission 2024-25'])[1]/preceding::span[2]</value>
      <webElementGuid>cafbb825-8e31-488d-a06a-026e811e9efe</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='UG Admission 2024-25']/parent::*</value>
      <webElementGuid>ac25bfcf-ce3e-4ac9-a5ce-2b22aca2e0a1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//b/span</value>
      <webElementGuid>ca793238-e63a-48cd-9f42-1a77d7395d78</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'UG Admission 2024-25' or . = 'UG Admission 2024-25')]</value>
      <webElementGuid>b008bdc4-e462-4e31-a0dc-1164b7ac3481</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
