<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_AlumniCorporate(CEGACTMITSAP)Sustainabi_77ba8c</name>
   <tag></tag>
   <elementGuidId>30f3c940-ed8c-418b-8694-61d31a6c6e38</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//body[@id='bg']/div/header/div/div/div[2]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.mt-3</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Alumni/Corporate(CEG/ACT/MIT/SAP) Sustainability CEAP 2024(M.E./M.Tech./M.Arch./&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>c82ecb58-18f8-4cf6-9523-7c3bf16ed1b6</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>mt-3</value>
      <webElementGuid>5c2ed330-8274-48d9-a8a0-17ee01abaced</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>align</name>
      <type>Main</type>
      <value>center</value>
      <webElementGuid>fc6b5414-d0a1-4882-a62e-fae22df789b8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>  
			
				
			
			
				
					Alumni/Corporate(CEG/ACT/MIT/SAP)
				
			
			
				
					Sustainability
				
			
			
			
										
					CEAP 2024(M.E./M.Tech./M.Arch./M.Plan.)
				Rank List &amp; Counseling:
					CEETA-PG				
			
			
			
				
				
					UG Admission 2024-25
					
					B.E.(Training Integrated)
				
								
			
					
						
						PG Admission 2024-25
						
						
						NRI/FN/CIWGC(PG Category)
						
						
					
		</value>
      <webElementGuid>57a1458f-5d15-481a-8487-17bd129e75a7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;bg&quot;)/div[@class=&quot;page-wraper&quot;]/header[@class=&quot;site-header mo-left header&quot;]/div[@class=&quot;sticky-header main-bar-wraper navbar-expand-lg&quot;]/div[@class=&quot;main-bar clearfix&quot;]/div[@class=&quot;mt-3&quot;]</value>
      <webElementGuid>fc085dc8-f710-4595-bffd-de2aa8e7019b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//body[@id='bg']/div/header/div/div/div[2]</value>
      <webElementGuid>52ec7957-22e9-4e05-ba08-126b4126cb78</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact Us'])[1]/following::div[1]</value>
      <webElementGuid>c366cd85-e5aa-4121-b29f-1c29c7c16d17</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='RCC'])[1]/following::div[1]</value>
      <webElementGuid>5944bfd5-3fb2-4f2e-85e7-b5b620e5b758</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/div[2]</value>
      <webElementGuid>2e4eb6a2-725a-420f-a41e-eeef4577d174</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '  
			
				
			
			
				
					Alumni/Corporate(CEG/ACT/MIT/SAP)
				
			
			
				
					Sustainability
				
			
			
			
										
					CEAP 2024(M.E./M.Tech./M.Arch./M.Plan.)
				Rank List &amp; Counseling:
					CEETA-PG				
			
			
			
				
				
					UG Admission 2024-25
					
					B.E.(Training Integrated)
				
								
			
					
						
						PG Admission 2024-25
						
						
						NRI/FN/CIWGC(PG Category)
						
						
					
		' or . = '  
			
				
			
			
				
					Alumni/Corporate(CEG/ACT/MIT/SAP)
				
			
			
				
					Sustainability
				
			
			
			
										
					CEAP 2024(M.E./M.Tech./M.Arch./M.Plan.)
				Rank List &amp; Counseling:
					CEETA-PG				
			
			
			
				
				
					UG Admission 2024-25
					
					B.E.(Training Integrated)
				
								
			
					
						
						PG Admission 2024-25
						
						
						NRI/FN/CIWGC(PG Category)
						
						
					
		')]</value>
      <webElementGuid>62610122-b557-43a5-b79d-029054ef9caf</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
