<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_CUIC Courses</name>
   <tag></tag>
   <elementGuidId>7c993748-d324-4c3b-a46f-8f7d09a88c59</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//header[@id='header-one']/div/div/div/div[2]/div/nav/div/dd/ul/li[7]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;CUIC Courses&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>4e30fc8e-7762-48ce-8972-80c4b8de1d3d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://b-u.ac.in/142/industry-relevant-courses</value>
      <webElementGuid>814ac0bc-c7b8-4dd5-babc-d91ba43fe592</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>CUIC Courses</value>
      <webElementGuid>6c597b5c-78b1-4074-a1ae-8efd90c2a8ea</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;header-one&quot;)/div[@class=&quot;header-main&quot;]/div[@class=&quot;header-main-inner p-relative&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-7 col-sm-7 col-xs-7 content-inner&quot;]/div[@class=&quot;topbar-content&quot;]/nav[@class=&quot;top-rightmenu block block-menu navigation menu--about-bu&quot;]/div[@class=&quot;block-content&quot;]/dd[1]/ul[@class=&quot;gva_menu&quot;]/li[@class=&quot;menu-item&quot;]/a[1]</value>
      <webElementGuid>6e17859d-0106-4889-be8c-5a1138cb0f5c</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//header[@id='header-one']/div/div/div/div[2]/div/nav/div/dd/ul/li[7]/a</value>
      <webElementGuid>75131e94-92cd-4e9d-8557-882a5045a1b1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'CUIC Courses')]</value>
      <webElementGuid>304530d7-f374-4f15-a6d3-9663b7a70a8a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IQAC'])[1]/following::a[1]</value>
      <webElementGuid>b45c34b9-12f9-4522-a5b3-b68256299616</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Online Courses'])[1]/following::a[2]</value>
      <webElementGuid>cefb5b2d-f589-4c2b-a21b-5722d5671b5b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Syllabus'])[1]/preceding::a[1]</value>
      <webElementGuid>16a54d1c-8f00-4e7c-9bd2-88c9419851ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='×'])[1]/preceding::a[2]</value>
      <webElementGuid>fe0f93ae-9a63-4902-9a10-118d594ce194</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='CUIC Courses']/parent::*</value>
      <webElementGuid>9c3a359f-2792-48a3-876c-74b90e6991a8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://b-u.ac.in/142/industry-relevant-courses')]</value>
      <webElementGuid>8e0a38e1-2bbf-4605-8875-14566347cd0c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[7]/a</value>
      <webElementGuid>fb3fe0ff-441d-45de-b60c-e8c2a0a0e645</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://b-u.ac.in/142/industry-relevant-courses' and (text() = 'CUIC Courses' or . = 'CUIC Courses')]</value>
      <webElementGuid>0596b95d-6762-4112-a83a-7051803e00f2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
