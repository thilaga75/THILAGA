<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Know More</name>
   <tag></tag>
   <elementGuidId>a89f3184-e405-4cfa-af63-9ca6f784b3f6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='owl-demo-3']/div/div/div[8]/div/div/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.owl-item.active > div.item > div.knwmor-annunc > a.btn.btn-warning.know-mor-ornge_bnr</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>div:nth-child(8) > .item > .knwmor-annunc > .btn</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>af069b0a-3be7-4157-9b51-837d4bdf280d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://www.sju.edu.in/view-pdf/sjurecuirtment8june</value>
      <webElementGuid>acb5c968-4941-4faf-aa1c-d12cafc1d2e7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-warning know-mor-ornge_bnr</value>
      <webElementGuid>01c8d26b-2c6e-40f1-ba7d-d8d50c881704</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Know More </value>
      <webElementGuid>0830e9c5-16c9-49cd-96b5-6592d2719361</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;owl-demo-3&quot;)/div[@class=&quot;owl-stage-outer&quot;]/div[@class=&quot;owl-stage&quot;]/div[@class=&quot;owl-item active&quot;]/div[@class=&quot;item&quot;]/div[@class=&quot;knwmor-annunc&quot;]/a[@class=&quot;btn btn-warning know-mor-ornge_bnr&quot;]</value>
      <webElementGuid>1f40cd86-2614-4e56-8ad4-a9d248833c58</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='owl-demo-3']/div/div/div[8]/div/div/a</value>
      <webElementGuid>b5c40aea-403a-4641-89e7-51bd9457a864</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>(//a[contains(text(),'Know More')])[8]</value>
      <webElementGuid>07dcfb23-22d1-4cc8-b12e-4f5f1b3674f7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Know More'])[7]/following::a[1]</value>
      <webElementGuid>27703a54-e6dd-4d0e-96c2-d1224e958c49</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Know More'])[6]/following::a[2]</value>
      <webElementGuid>7c76247a-84bc-41f1-bf74-730a3a2bf2eb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Know More'])[9]/preceding::a[1]</value>
      <webElementGuid>7ed127ae-4f5b-4aff-993d-f45248508ffb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Know More'])[10]/preceding::a[2]</value>
      <webElementGuid>9e5ced07-b465-4cec-aa67-553fb8a176b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://www.sju.edu.in/view-pdf/sjurecuirtment8june')]</value>
      <webElementGuid>b39e1623-2ff7-49bc-8ccd-a1a6f209f71d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[8]/div/div/a</value>
      <webElementGuid>27ac0749-577c-49ca-ae28-476bbadc090f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://www.sju.edu.in/view-pdf/sjurecuirtment8june' and (text() = ' Know More ' or . = ' Know More ')]</value>
      <webElementGuid>6729bd7a-01eb-4ce9-b300-8a32adb2105e</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
