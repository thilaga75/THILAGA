<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Create and manage communities, study mate_1b5745</name>
   <tag></tag>
   <elementGuidId>0894c81a-7789-4b3a-bb05-833f3c0c2d6d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Streamline your academic workflow with Linways AMS'])[1]/following::p[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>p.lead</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Create and manage communities, study materials, question papers, course files, d&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>22d201fb-4369-4be9-9f63-2a4a8dd1dcbf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>lead</value>
      <webElementGuid>dad17711-2593-48b1-b9bf-2fb8bd237c09</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Create and manage communities, study materials, question papers, course files, desired outcomes, and a lot more! </value>
      <webElementGuid>75ec6a72-2cb7-4e29-82b5-78a630cef895</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[1]/div[@class=&quot;main-container&quot;]/section[@class=&quot;switchable slider padding-7&quot;]/ul[@class=&quot;slides flickity-enabled is-draggable&quot;]/div[@class=&quot;flickity-viewport&quot;]/div[@class=&quot;flickity-slider&quot;]/li[@class=&quot;slide is-selected&quot;]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-5 col-sm-7&quot;]/div[@class=&quot;mt--2&quot;]/p[@class=&quot;lead&quot;]</value>
      <webElementGuid>15dcbf07-9998-48ca-a007-d271eb22973f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Streamline your academic workflow with Linways AMS'])[1]/following::p[1]</value>
      <webElementGuid>652be2f3-31be-41d1-8ddc-cfee8506e7b4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Schedule a Demo'])[1]/following::p[1]</value>
      <webElementGuid>bcb8b2e0-ede1-46a2-b232-91f928f7ffd3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Schedule a Demo'])[2]/preceding::p[1]</value>
      <webElementGuid>4226ad3d-e6c9-4c6c-b159-03c4aba9bb28</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='OBE, CBE, SCL… You name it. We have it.'])[1]/preceding::p[1]</value>
      <webElementGuid>b27b0584-d433-4d4d-82be-30c08056f777</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Create and manage communities, study materials, question papers, course files, desired outcomes, and a lot more!']/parent::*</value>
      <webElementGuid>70883739-a48b-4284-b3c6-7dd691bdd0c8</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//p</value>
      <webElementGuid>53a84432-6c1e-4caf-abfd-d82cc1e0ccc3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = ' Create and manage communities, study materials, question papers, course files, desired outcomes, and a lot more! ' or . = ' Create and manage communities, study materials, question papers, course files, desired outcomes, and a lot more! ')]</value>
      <webElementGuid>d97ffe30-5e78-4cd8-9b1f-23be7c58456b</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
