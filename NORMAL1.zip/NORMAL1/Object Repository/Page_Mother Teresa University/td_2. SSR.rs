<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>td_2. SSR</name>
   <tag></tag>
   <elementGuidId>ecc20ab6-292b-45c8-a26f-46a93b2faf3b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//table[@id='customers']/tbody/tr[3]/td</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(3) > td</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;2. SSR&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>td</value>
      <webElementGuid>58a4b9ff-4ebe-4857-8d88-792b71150ac1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>2. SSR</value>
      <webElementGuid>322b5b0f-06f1-486f-88d5-6a967b4f8977</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;customers&quot;)/tbody[1]/tr[3]/td[1]</value>
      <webElementGuid>62c9adde-19e0-4f65-bdd5-f9524bf39955</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//table[@id='customers']/tbody/tr[3]/td</value>
      <webElementGuid>51e8ffe2-5f8e-4d89-b8b2-0e7cc693d4a0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='NAAC - ACCREDITATION III CYCLE'])[1]/following::td[3]</value>
      <webElementGuid>531417f5-c7a3-4137-9d9e-5d8bf811c046</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dr.A.Usha Raja Nanthini'])[1]/following::td[3]</value>
      <webElementGuid>2732e3f3-4aee-4735-9a2f-5e82eb96a3de</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='VC Message'])[3]/preceding::td[2]</value>
      <webElementGuid>243906a3-0335-418b-823a-fc0757889f15</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='2. SSR']/parent::*</value>
      <webElementGuid>c91c053d-325b-498f-aa80-fc870a96057f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[3]/td</value>
      <webElementGuid>6822c424-c75c-479e-ac74-30c6506c0236</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//td[(text() = '2. SSR' or . = '2. SSR')]</value>
      <webElementGuid>77050864-94a5-4aa2-8b8a-2c00a7900fa2</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
