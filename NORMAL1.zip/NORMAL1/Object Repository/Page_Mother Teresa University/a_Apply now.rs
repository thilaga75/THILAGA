<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Apply now</name>
   <tag></tag>
   <elementGuidId>3a83d465-6ef6-45e9-9e07-4514fca1c453</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[contains(text(),'Apply now')]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a.apply-now-button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Apply now&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>c4af2b0b-1651-4216-8601-dba951699495</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>apply-now-button</value>
      <webElementGuid>8e18f680-4ac6-4c05-8f0e-f0e52a04e97f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://www.motherteresawomenuniv.ac.in/mwu/admission_2024</value>
      <webElementGuid>20d9758d-5508-4b12-a963-570fdf5ed2bc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Apply now </value>
      <webElementGuid>475f43c8-edec-47f1-92e2-63dd3a87e242</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;theme-vankine ReactModal__Body--open&quot;]/div[@class=&quot;ReactModalPortal&quot;]/div[@class=&quot;ReactModal__Overlay ReactModal__Overlay--after-open modal-overlay&quot;]/div[@class=&quot;ReactModal__Content ReactModal__Content--after-open modal-content&quot;]/div[@class=&quot;modal-body&quot;]/li[1]/a[@class=&quot;apply-now-button&quot;]</value>
      <webElementGuid>01e20350-7909-4c1d-aedc-ad9d6ae9a564</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Apply now')]</value>
      <webElementGuid>928153a0-f1b8-4e15-bd4b-07be86f6c761</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Admissions Open 2024'])[1]/following::a[1]</value>
      <webElementGuid>251c54ba-89f0-418e-84b7-80cc04ec6c92</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Apply now']/parent::*</value>
      <webElementGuid>cc5ebfda-d5b6-42ac-ad2a-65041b7c6f9f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, 'https://www.motherteresawomenuniv.ac.in/mwu/admission_2024')])[4]</value>
      <webElementGuid>a1a51fbe-4991-42a8-a21f-205bf6996f6f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div/li/a</value>
      <webElementGuid>fea9086a-469c-45c3-bcb3-ccd0662be6d6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://www.motherteresawomenuniv.ac.in/mwu/admission_2024' and (text() = 'Apply now ' or . = 'Apply now ')]</value>
      <webElementGuid>b8e82629-499b-4f2c-bf1c-80a307571df7</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
