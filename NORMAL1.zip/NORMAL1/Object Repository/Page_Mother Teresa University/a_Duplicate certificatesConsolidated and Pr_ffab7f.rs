<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Duplicate certificatesConsolidated and Pr_ffab7f</name>
   <tag></tag>
   <elementGuidId>3418d5db-0515-46e1-842a-94c015160e48</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='header_contents']/header/div/div/div/div/marquee/span[3]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span:nth-of-type(3) > a.glow</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Duplicate certificates/Consolidated and Provisional Certificate/Degree Certificate&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>5d9444ce-bed8-4521-ad62-447b4cee55eb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>https://drive.motherteresawomenuniv.ac.in/drive/s/31yAKtK84yAoWuTkjpGEMFlGKxhlQK</value>
      <webElementGuid>c8f3b8c3-47dc-4c87-8a25-6c4ecc4e1eaa</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>glow</value>
      <webElementGuid>923dd19c-5d67-411c-9a48-c4763c0cc3fd</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Duplicate certificates/Consolidated and Provisional Certificate/Degree Certificate</value>
      <webElementGuid>debfbd3b-b4ee-41a2-9322-69c2826100c5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;header_contents&quot;)/header[@class=&quot;header-area header-style-1 htype_one&quot;]/div[@class=&quot;top_bar&quot;]/div[@class=&quot;large-container&quot;]/div[@class=&quot;row align-items-center&quot;]/div[@class=&quot;col-lg-9 col-md-12 col-sm-12 col-xs-12&quot;]/marquee[1]/span[3]/a[@class=&quot;glow&quot;]</value>
      <webElementGuid>eae3eff6-5c9a-4f5f-8adb-013e858ecfdd</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='header_contents']/header/div/div/div/div/marquee/span[3]/a</value>
      <webElementGuid>936e1335-4f5f-4290-97d4-8f95a13ca255</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Duplicate certificates/Consolidated and Provisional Certificate/Degree Certificate')]</value>
      <webElementGuid>db7ea223-53ca-42ce-9f06-5bc7033e18d0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Heading For benchmark disabilities'])[1]/following::a[1]</value>
      <webElementGuid>a3437f01-038d-4e56-a57c-d5d19604e524</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Ph.D. Entrance Examination June - extended to 13.6.2024'])[1]/following::a[2]</value>
      <webElementGuid>c21f5db6-4dd6-4055-9d57-1bcc17ab465e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Distance Education June and July 2024 Examinations'])[1]/preceding::a[1]</value>
      <webElementGuid>967865bb-08d3-453c-a217-0e65b3022841</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='News Flash June-November 2022 link'])[1]/preceding::a[3]</value>
      <webElementGuid>fad4f745-03c3-4520-af45-fc93b9b75d98</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Duplicate certificates/Consolidated and Provisional Certificate/Degree Certificate']/parent::*</value>
      <webElementGuid>7f661ff6-425c-4f5e-80b5-3f9b91b932a1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'https://drive.motherteresawomenuniv.ac.in/drive/s/31yAKtK84yAoWuTkjpGEMFlGKxhlQK')]</value>
      <webElementGuid>26f21f69-b122-4f30-ab71-73a22b76a885</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//span[3]/a</value>
      <webElementGuid>3b6a45cc-98ac-48b8-abf5-90a1138614b9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'https://drive.motherteresawomenuniv.ac.in/drive/s/31yAKtK84yAoWuTkjpGEMFlGKxhlQK' and (text() = 'Duplicate certificates/Consolidated and Provisional Certificate/Degree Certificate' or . = 'Duplicate certificates/Consolidated and Provisional Certificate/Degree Certificate')]</value>
      <webElementGuid>fbdb6629-3812-449e-88ce-8ef4a4f7e039</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
