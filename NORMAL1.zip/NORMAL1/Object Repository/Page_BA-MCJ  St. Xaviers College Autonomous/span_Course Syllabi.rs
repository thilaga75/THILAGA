<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Course Syllabi</name>
   <tag></tag>
   <elementGuidId>9183d64a-1cc2-4083-9a42-a831b0b7cac8</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='Section1']/div/div/div[2]/div/div/div/div/div/div[3]/div/div/div/div/a/span</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Course Syllabi&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>7bc62f09-d5a6-45b1-9e51-a199c1ad1d53</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Course Syllabi</value>
      <webElementGuid>bc21b476-44f5-4b4a-bdf8-4edf056860ce</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;Section1&quot;)/div[@class=&quot;StripPreview_backgroundComponent__3YmQM Background_backgroundComponent__3_1Ea hasChildren&quot;]/div[@class=&quot;Preview_column__1KeVx col&quot;]/div[@class=&quot;Preview_row__3Fkye row&quot;]/div[@class=&quot;Preview_componentWrapper__2i4QI&quot;]/div[@class=&quot;Preview_block__16Zmu&quot;]/div[@class=&quot;BackgroundPreview_backgroundComponent__3Dr5e BackgroundPreview_bgHeight__3dD2e hasChildren&quot;]/div[@class=&quot;Preview_column__1KeVx col&quot;]/div[@class=&quot;Preview_row__3Fkye row&quot;]/div[@class=&quot;Preview_column__1KeVx col isExpandable&quot;]/div[@class=&quot;Preview_componentWrapper__2i4QI&quot;]/div[@class=&quot;Preview_component__SbiKo align-center&quot;]/div[@class=&quot;ButtonPreview_container__22hQi ButtonPreview_buttonTransition__CKIAx button1 Main primary themeButtonClass&quot;]/div[@class=&quot;ButtonPreview_buttonComponent__17NP0&quot;]/a[@class=&quot;ButtonPreview_textContainer__t8q7_&quot;]/span[1]</value>
      <webElementGuid>4adc4ccd-b068-448d-9f91-3dc977aed498</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='Section1']/div/div/div[2]/div/div/div/div/div/div[3]/div/div/div/div/a/span</value>
      <webElementGuid>01dac97c-45bf-4f5d-aec2-78bedc709145</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SCHOLARSHIP'])[1]/following::span[1]</value>
      <webElementGuid>db270d4d-3bfa-4510-bb9d-717e4dc2019c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Admission'])[1]/following::span[2]</value>
      <webElementGuid>49b27034-00eb-46fa-8611-aaa9612bb8f1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='SEATS'])[1]/preceding::span[2]</value>
      <webElementGuid>5140a2dd-6e3f-4023-8068-9e6da4e0c996</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='F.Y.B.A (MCJ) (120 seats)'])[1]/preceding::span[3]</value>
      <webElementGuid>d5b580fb-4d39-4846-82f4-8f132aa18bef</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Course Syllabi']/parent::*</value>
      <webElementGuid>7007a656-e9cd-43a6-8975-305d7e38f794</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/div/div/div/a/span</value>
      <webElementGuid>3c769783-b152-4038-be15-2affa892c0e5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Course Syllabi' or . = 'Course Syllabi')]</value>
      <webElementGuid>6f3a6666-78c0-4edd-8458-572a4a44210f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
