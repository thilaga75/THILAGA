<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Centre for Admissions (CFA) is entrusted _a7d11f</name>
   <tag></tag>
   <elementGuidId>d8aa9200-b0ce-46c1-8598-56b2a0589dfb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='aboutus']/div/div/div[2]/div/div/p</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.rcorners2 > div > p</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;Centre for Admissions (CFA) is entrusted with the conduct of admissions to the U&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
      <webElementGuid>e5b6672a-131a-49df-a3f7-3332846b21ee</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Centre for Admissions (CFA) is entrusted with the conduct of admissions to the UG programs offered in the University Departments of Anna University (College of Engineering (CEG),Guindy ,Chennai -25, Alagappa College of Technology (ACT), Guindy, School of Architecture and Planning (SAP), Guindy and Madras Institute of Technology (MIT) , Chrompet, Chennai-44, under the various  categories detailed below:</value>
      <webElementGuid>dc3e6588-2af3-40de-81a4-78dcaff57d30</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;aboutus&quot;)/div[@class=&quot;container full-width&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-9&quot;]/div[@class=&quot;rcorners2&quot;]/div[1]/p[1]</value>
      <webElementGuid>886ce2a2-ca1b-4bce-8d87-24787340a6c4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='aboutus']/div/div/div[2]/div/div/p</value>
      <webElementGuid>8c76c16e-db3c-43a9-b072-9b95ac517969</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='UNDERGRADUATE (UG) ADMISSIONS'])[1]/following::p[1]</value>
      <webElementGuid>b7f77a00-0945-4374-939a-b61aca67254f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ADMISSIONS 2024-25'])[1]/following::p[1]</value>
      <webElementGuid>d12a79c6-155e-47af-ac43-e94b20347511</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='o Non-Resident Indians(NRI)'])[1]/preceding::p[2]</value>
      <webElementGuid>c07f5ed9-7bec-4a1d-8753-5b40f125dfe4</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='o Children of Indian Workers in Gulf Countries(CIWGC)'])[1]/preceding::p[2]</value>
      <webElementGuid>a28f0c4f-ca50-4249-bb4d-73c072d3af9b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/div/p</value>
      <webElementGuid>1b55dce9-fde3-4f17-847d-c234c2593a77</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//p[(text() = 'Centre for Admissions (CFA) is entrusted with the conduct of admissions to the UG programs offered in the University Departments of Anna University (College of Engineering (CEG),Guindy ,Chennai -25, Alagappa College of Technology (ACT), Guindy, School of Architecture and Planning (SAP), Guindy and Madras Institute of Technology (MIT) , Chrompet, Chennai-44, under the various  categories detailed below:' or . = 'Centre for Admissions (CFA) is entrusted with the conduct of admissions to the UG programs offered in the University Departments of Anna University (College of Engineering (CEG),Guindy ,Chennai -25, Alagappa College of Technology (ACT), Guindy, School of Architecture and Planning (SAP), Guindy and Madras Institute of Technology (MIT) , Chrompet, Chennai-44, under the various  categories detailed below:')]</value>
      <webElementGuid>3f6e5f5e-3427-4b4e-87a8-a926da7f314a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
