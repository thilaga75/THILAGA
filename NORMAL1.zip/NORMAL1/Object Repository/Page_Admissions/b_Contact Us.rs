<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>b_Contact Us</name>
   <tag></tag>
   <elementGuidId>b1322682-990f-48dc-bbcb-04cd1a514000</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='mainav']/ul/li[5]/a/b</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(5) > a > b</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Contact Us&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>b</value>
      <webElementGuid>cd145665-ad0b-4c9f-b809-82f14aa95f3d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Contact Us</value>
      <webElementGuid>8c32a617-93ab-4f44-a6cd-a00175885e29</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mainav&quot;)/ul[@class=&quot;clear&quot;]/li[5]/a[1]/b[1]</value>
      <webElementGuid>448aacd6-9736-4bbb-a132-fa3ba441a612</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='mainav']/ul/li[5]/a/b</value>
      <webElementGuid>62d04541-9716-4a88-8a83-fd4e155f0ec1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CONSORTIUM (PG)'])[1]/following::b[1]</value>
      <webElementGuid>f3197f31-a396-485c-8ed8-f027f9006ece</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CIWGC'])[8]/following::b[1]</value>
      <webElementGuid>df3a38fc-ec8a-4ba4-894e-b31f71cabfcd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Online Registration'])[1]/preceding::b[2]</value>
      <webElementGuid>b6cd3b7d-a2b6-439c-a368-7da0f58b58f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Contact Us']/parent::*</value>
      <webElementGuid>a80404a9-dd37-4405-927f-09ed96e682bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[5]/a/b</value>
      <webElementGuid>1f44f504-1350-48d1-a37e-e9518d45e7f2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//b[(text() = 'Contact Us' or . = 'Contact Us')]</value>
      <webElementGuid>8cb57220-91f2-4fa8-9796-d1fd7e9bb8e8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
