<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>b_M.E.  M.Tech.  M.Plan.  M.Arch. Degree  P_dbbdc6</name>
   <tag></tag>
   <elementGuidId>766975c7-0dfe-4342-ae2c-2e2058ccb0df</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//body[@id='top']/div[4]/div/div/div/div/b</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div.panel-heading > b</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;M.E. / M.Tech. / M.Plan. / M.Arch. Degree Programmes under NRI / CIWGC / FN cate&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>b</value>
      <webElementGuid>58dc4b11-aef1-40d8-8898-c4b709577559</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>M.E. / M.Tech. / M.Plan. / M.Arch. Degree  Programmes  under NRI / CIWGC / FN category</value>
      <webElementGuid>a132834e-7ff1-4a76-bb45-adb30b737126</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;top&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-4&quot;]/div[@class=&quot;panel6&quot;]/div[@class=&quot;panel-heading&quot;]/b[1]</value>
      <webElementGuid>e152f34e-2ee2-403b-b4c8-a04af7b2f0ec</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//body[@id='top']/div[4]/div/div/div/div/b</value>
      <webElementGuid>881dadf1-95df-4106-bf1f-5e8d50e1c4dd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Contact Us'])[1]/following::b[1]</value>
      <webElementGuid>50ee7a2a-cb5e-473a-bce2-a5234b1674f9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CONSORTIUM (PG)'])[1]/following::b[2]</value>
      <webElementGuid>e4ad8e6f-4634-4925-8c61-a2199155a6ae</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Online Registration'])[1]/preceding::b[1]</value>
      <webElementGuid>af015b27-0afb-4499-897c-2b879284293e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='M.E. / M.Tech. / M.Plan. / M.Arch. Degree']/parent::*</value>
      <webElementGuid>2bbd01d0-1524-4d1d-bd7a-b2d068bc4eff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/div/div/div/div/b</value>
      <webElementGuid>555783f8-5a30-4d77-ad04-9c5260102cc7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//b[(text() = 'M.E. / M.Tech. / M.Plan. / M.Arch. Degree  Programmes  under NRI / CIWGC / FN category' or . = 'M.E. / M.Tech. / M.Plan. / M.Arch. Degree  Programmes  under NRI / CIWGC / FN category')]</value>
      <webElementGuid>8f19906a-3bac-4cd4-b999-d642b1b57c83</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
