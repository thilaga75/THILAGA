<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>centre_Online Registration</name>
   <tag></tag>
   <elementGuidId>b10b0ce0-eee7-46ea-9b11-dcf248728f30</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//section[@id='aboutus']/div/div/div/button[6]/centre/p/a/b/centre</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=button[name=&quot;NRI / FN / CIWGC (PG Category) Online Registration&quot;i] >> internal:role=link</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>centre</value>
      <webElementGuid>170023cb-5869-423e-8bb9-41f41d728a12</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Online Registration</value>
      <webElementGuid>71d9d1ea-115c-4c44-8876-dba7c6789933</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;aboutus&quot;)/div[@class=&quot;container full-width&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-3&quot;]/button[@class=&quot;button button2&quot;]/centre[1]/p[1]/a[1]/b[1]/centre[1]</value>
      <webElementGuid>78db41b8-ebba-4f9b-9a43-732d0f921d31</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//section[@id='aboutus']/div/div/div/button[6]/centre/p/a/b/centre</value>
      <webElementGuid>c61a5998-508a-46e3-9961-dddec47285e0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Online Registration'])[2]/following::centre[2]</value>
      <webElementGuid>54c85a3e-edfd-454f-a02c-2f4ea10a6104</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Online Registration'])[1]/following::centre[4]</value>
      <webElementGuid>b453d1ad-80ac-4126-b21f-08e88535a76c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='ADMISSIONS 2024-25'])[1]/preceding::centre[1]</value>
      <webElementGuid>38987040-35b6-42f5-9aca-9d1baa989d8a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='UNDERGRADUATE (UG) ADMISSIONS'])[1]/preceding::centre[1]</value>
      <webElementGuid>94714cd1-1147-4df5-b81a-6e3b6324c270</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//button[6]/centre/p/a/b/centre</value>
      <webElementGuid>88c0fa35-a9c3-4447-ac8a-96c142a3edaf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//centre[(text() = 'Online Registration' or . = 'Online Registration')]</value>
      <webElementGuid>7d8914ab-11f8-4335-8065-1b66c8382de6</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
