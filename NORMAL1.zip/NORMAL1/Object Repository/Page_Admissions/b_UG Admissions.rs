<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>b_UG Admissions</name>
   <tag></tag>
   <elementGuidId>d5755183-326c-4901-91f1-8d2a4616849f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='mainav']/ul/li[3]/a/b</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>li:nth-of-type(3) > a.drop > b</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;UG Admissions &quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>b</value>
      <webElementGuid>a144e170-5fca-4c00-9acd-eed0e18a5890</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>UG Admissions</value>
      <webElementGuid>91b2e1e1-d424-4c8b-9b54-6e9da4abb742</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mainav&quot;)/ul[@class=&quot;clear&quot;]/li[3]/a[@class=&quot;drop&quot;]/b[1]</value>
      <webElementGuid>30bcc282-d832-48fd-ba40-b327b3cde830</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='mainav']/ul/li[3]/a/b</value>
      <webElementGuid>d3e02c50-797a-4abe-bc5a-c763f2317d74</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Staff'])[1]/following::b[1]</value>
      <webElementGuid>e391db50-1125-46aa-9a96-1fbe48d1131c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Directors'])[1]/following::b[2]</value>
      <webElementGuid>cbfdd7a3-9d81-4978-b9d8-67edbbfa5dfa</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='OTHER STATE'])[1]/preceding::b[1]</value>
      <webElementGuid>06456268-36fb-496b-8be3-c5121d143ab3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CONSORTIUM'])[1]/preceding::b[1]</value>
      <webElementGuid>5ee58ce6-080b-495f-99d3-3eb18734dfdb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='UG Admissions']/parent::*</value>
      <webElementGuid>c7c1154a-120f-427b-9a7c-bb2de2d6b20d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[3]/a/b</value>
      <webElementGuid>9d675a18-baf3-4387-a722-b299daefe17a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//b[(text() = 'UG Admissions' or . = 'UG Admissions')]</value>
      <webElementGuid>9837b499-c2f0-46f4-8d3e-4438e44a41cd</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
