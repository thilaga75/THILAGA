<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>b_University College of Engineering   Trich_9ba3bb</name>
   <tag></tag>
   <elementGuidId>622ab1f0-0e34-4f5c-9c63-c795c441cf80</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//table[@id='table-example-1']/tbody[2]/tr[4]/td/b</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>tr:nth-of-type(4) > td > b</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;University College of Engineering Trichy (BIT Campus)&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>b</value>
      <webElementGuid>ef76bac1-bf67-4e21-866d-d882b89a4ccf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>  University College of Engineering   Trichy   (BIT Campus)</value>
      <webElementGuid>140796ef-efc2-4ca7-95a9-984f64188745</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;table-example-1&quot;)/tbody[2]/tr[4]/td[1]/b[1]</value>
      <webElementGuid>4f51c3d2-2fdd-4449-8435-cb4b2836857b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//table[@id='table-example-1']/tbody[2]/tr[4]/td/b</value>
      <webElementGuid>28379102-9cc1-4c1f-8e3a-9f4ec9aad781</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mechanical Engineering'])[2]/following::b[1]</value>
      <webElementGuid>dff2ca3d-73d3-4ccb-8bdd-128968c3f384</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Madras Institute of TechnologyChrompet'])[1]/following::b[2]</value>
      <webElementGuid>5df53af7-aa99-4920-a014-2197e9342ae0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Civil Engineering'])[2]/preceding::b[1]</value>
      <webElementGuid>9fe8f859-fccb-4521-b01e-3d254676ab40</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mechanical Engineering'])[3]/preceding::b[1]</value>
      <webElementGuid>41baaa60-da95-4288-9794-fa92a3295e76</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='University College of Engineering']/parent::*</value>
      <webElementGuid>6cd9404f-7a7a-4077-ac80-a5ad17f5ca4c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//tr[4]/td/b</value>
      <webElementGuid>b0394109-a578-4b45-92d7-0a9b0bf47398</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//b[(text() = '  University College of Engineering   Trichy   (BIT Campus)' or . = '  University College of Engineering   Trichy   (BIT Campus)')]</value>
      <webElementGuid>fab20f3f-e9f5-436b-a79c-bfc943d71673</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
