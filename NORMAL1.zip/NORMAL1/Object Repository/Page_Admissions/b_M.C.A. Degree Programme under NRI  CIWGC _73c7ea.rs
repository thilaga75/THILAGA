<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>b_M.C.A. Degree Programme under NRI  CIWGC _73c7ea</name>
   <tag></tag>
   <elementGuidId>8f5193de-1a4f-4d68-8892-8361d4c32b0a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//body[@id='top']/div[4]/div/b/b/div/div/div/b</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>b > div.col-sm-4 > div.panel6 > div.panel-heading > b</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:text=&quot;M.C.A. Degree Programme under NRI / CIWGC / FN category&quot;i</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>b</value>
      <webElementGuid>ff5f57cb-1695-4ca5-9c3b-6df4619ae114</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>M.C.A. Degree Programme 
under NRI / CIWGC / FN category</value>
      <webElementGuid>0c575097-2a2b-44a0-a150-d454ddfff45e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;top&quot;)/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/b[1]/b[1]/div[@class=&quot;col-sm-4&quot;]/div[@class=&quot;panel6&quot;]/div[@class=&quot;panel-heading&quot;]/b[1]</value>
      <webElementGuid>2c0576ac-869f-401c-9aff-423b331f21c4</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//body[@id='top']/div[4]/div/b/b/div/div/div/b</value>
      <webElementGuid>e69544ee-54b5-4dc9-b051-ab1393ec5a2d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Online Registration'])[2]/following::b[5]</value>
      <webElementGuid>9cec5ff7-60f5-4f9e-aea9-6e98c5818909</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Online Registration'])[3]/preceding::b[2]</value>
      <webElementGuid>b545b6f4-025f-482e-baf8-e258564eca18</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='M.C.A. Degree Programme']/parent::*</value>
      <webElementGuid>9ad1e14e-2148-4cb0-b33b-1accc5f28c1c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//b/div/div/div/b</value>
      <webElementGuid>83d30c6c-d071-40d1-8250-b769b36b21ab</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//b[(text() = 'M.C.A. Degree Programme 
under NRI / CIWGC / FN category' or . = 'M.C.A. Degree Programme 
under NRI / CIWGC / FN category')]</value>
      <webElementGuid>e0971f8e-ea52-4a20-b18a-c774adadbe3f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
