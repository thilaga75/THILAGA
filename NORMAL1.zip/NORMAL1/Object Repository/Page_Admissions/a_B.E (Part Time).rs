<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_B.E (Part Time)</name>
   <tag></tag>
   <elementGuidId>c4f9762b-aed6-4b5c-96fc-10235701ee1e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//nav[@id='mainav']/ul/li[3]/ul/li[4]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>ul.clear > li:nth-of-type(3) > ul > li:nth-of-type(4) > a</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;B.E (Part Time)&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>bd265ff2-1d8e-4974-bc2d-2167628e0f1a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>parttime.html</value>
      <webElementGuid>87bb1b24-8e2f-4fcf-aa14-d0549c88742d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>B.E (Part Time)</value>
      <webElementGuid>c65aa71f-bf90-4347-afb9-0ee0c7f3cae7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mainav&quot;)/ul[@class=&quot;clear&quot;]/li[3]/ul[1]/li[4]/a[1]</value>
      <webElementGuid>acc6b860-2198-477a-a06c-9af139999b3d</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//nav[@id='mainav']/ul/li[3]/ul/li[4]/a</value>
      <webElementGuid>1deec9f3-fa30-4805-9379-cbf1e21ba0f2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'B.E (Part Time)')]</value>
      <webElementGuid>93fb1611-2f28-4b09-a7ce-54ae688d7fb7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CIWGC'])[3]/following::a[1]</value>
      <webElementGuid>764deae9-1a83-49ed-a97e-3e17a124d69c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='FOREIGN NATIONALS'])[3]/following::a[2]</value>
      <webElementGuid>b0f46375-2609-4631-ad42-90329d3e76b0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='PG Admissions'])[1]/preceding::a[1]</value>
      <webElementGuid>3664a3ab-df5d-4cc7-95c4-dec0d749d5b6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='CEAP'])[1]/preceding::a[3]</value>
      <webElementGuid>8ee86638-f9fa-4eac-9332-7385e3566d1c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='B.E (Part Time)']/parent::*</value>
      <webElementGuid>8b3169de-e78a-4043-acf2-16b0061ff27d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, 'parttime.html')]</value>
      <webElementGuid>fad53434-3b25-4e72-ba60-5f89570c569f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//li[3]/ul/li[4]/a</value>
      <webElementGuid>98552cd5-f147-4d21-b60b-5f6a3da66893</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = 'parttime.html' and (text() = 'B.E (Part Time)' or . = 'B.E (Part Time)')]</value>
      <webElementGuid>59283186-fc0e-4634-956f-4d267b8acf5d</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
