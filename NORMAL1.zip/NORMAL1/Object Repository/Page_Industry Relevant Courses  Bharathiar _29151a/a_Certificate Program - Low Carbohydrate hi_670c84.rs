<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Certificate Program - Low Carbohydrate hi_670c84</name>
   <tag></tag>
   <elementGuidId>01d3c81a-338e-46ee-8cea-c2cb2859ab8e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='block-daudo-subtheme-content']/div/article/div/div[2]/div[2]/dl/dt[2]/a</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>dt:nth-of-type(2) > a.ckeditor-accordion-toggler</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=link[name=&quot;Certificate Program - Low Carbohydrate high Fat Nutritional Dietetics&quot;i]</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>03f2778f-eb0a-4871-9726-a3955fc9a8d4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ckeditor-accordion-toggler</value>
      <webElementGuid>6afa54ee-4275-47df-9470-a85d912a202a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>#</value>
      <webElementGuid>5bb6676d-58ee-4489-b9ef-b451b6620b18</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Certificate Program - Low Carbohydrate high Fat Nutritional Dietetics</value>
      <webElementGuid>41c2e638-344b-4ae7-a6c8-0e1f52aa7819</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;block-daudo-subtheme-content&quot;)/div[@class=&quot;content block-content&quot;]/article[@class=&quot;node node--type-main-page node--promoted node--view-mode-full clearfix&quot;]/div[@class=&quot;node__content clearfix&quot;]/div[@class=&quot;field field--name-body field--type-text-with-summary field--label-hidden field__item&quot;]/div[@class=&quot;ckeditor-accordion-container&quot;]/dl[@class=&quot;styled&quot;]/dt[2]/a[@class=&quot;ckeditor-accordion-toggler&quot;]</value>
      <webElementGuid>2052a250-4a51-4014-9f00-09d717b02c1f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='block-daudo-subtheme-content']/div/article/div/div[2]/div[2]/dl/dt[2]/a</value>
      <webElementGuid>09bc4fe0-e4bd-4b0e-8048-bf77f40281cb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Certificate Program - Low Carbohydrate high Fat Nutritional Dietetics')]</value>
      <webElementGuid>1c31da00-a539-43d2-9061-9aee0f083758</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Syllabus'])[3]/following::a[1]</value>
      <webElementGuid>fca07c23-3e90-449f-96a4-82c96e69e7ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Application'])[2]/following::a[2]</value>
      <webElementGuid>74986235-b7a9-4a92-a7d9-942bb9bb8a70</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Notification'])[2]/preceding::a[1]</value>
      <webElementGuid>d0be6c4a-766d-4bc6-b174-8e00b759d2bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Application'])[3]/preceding::a[2]</value>
      <webElementGuid>9678a0e9-6fde-48ea-bfab-882a31b16150</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Certificate Program - Low Carbohydrate high Fat Nutritional Dietetics']/parent::*</value>
      <webElementGuid>fa082f69-ffcd-43fa-9615-06b40a7b95c0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>(//a[contains(@href, '#')])[7]</value>
      <webElementGuid>9261eddd-d486-492d-bf5a-bfc903b528ff</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//dt[2]/a</value>
      <webElementGuid>b8f6c615-0cdf-44c7-86d6-d35bbd610efd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@href = '#' and (text() = 'Certificate Program - Low Carbohydrate high Fat Nutritional Dietetics' or . = 'Certificate Program - Low Carbohydrate high Fat Nutritional Dietetics')]</value>
      <webElementGuid>07069ef7-d446-4d3c-b0dd-693a7f1e9b67</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
