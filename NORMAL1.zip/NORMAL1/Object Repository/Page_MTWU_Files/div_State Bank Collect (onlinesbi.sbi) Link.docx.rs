<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_State Bank Collect (onlinesbi.sbi) Link.docx</name>
   <tag></tag>
   <elementGuidId>17af27c3-7838-49fa-882f-e0fdd04dba0d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='root']/div[2]/div[3]/table/tbody/tr/td/div</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <smartLocatorCollection>
      <entry>
         <key>SMART_LOCATOR</key>
         <value>internal:role=cell[name=&quot;State Bank Collect (onlinesbi.sbi) Link.docx&quot;i] >> div >> nth=0</value>
      </entry>
   </smartLocatorCollection>
   <smartLocatorEnabled>false</smartLocatorEnabled>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>7ccde6cb-04bd-4c73-8396-cecc312722f4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>flex items-center gap-14</value>
      <webElementGuid>b0eedebd-e73c-48f6-b095-ce7037850e2d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>State Bank Collect (onlinesbi.sbi) Link.docx</value>
      <webElementGuid>91cd0ef3-b3da-4e84-9160-f29780518efb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;root&quot;)/div[@class=&quot;dashboard-grid test-overflow h-full relative isolate&quot;]/div[@class=&quot;px-14 pb-14 md:px-24 md:pb-24 flex-auto overflow-auto file-grid-container dashboard-grid-content overflow-y-auto&quot;]/table[@class=&quot;select-none isolate outline-none text-sm w-full max-w-full align-top&quot;]/tbody[1]/tr[@class=&quot;break-inside-avoid border-b outline-none focus-visible:bg-focus hover:bg-hover&quot;]/td[@class=&quot;overflow-hidden whitespace-nowrap h-48 outline-none focus-visible:outline focus-visible:outline-offset-2 rounded text-left pl-24 pr-16 w-5/6 max-w-1&quot;]/div[@class=&quot;flex items-center gap-14&quot;]</value>
      <webElementGuid>f7446ae9-5b92-4f23-95d0-806b94cbe2a1</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='root']/div[2]/div[3]/table/tbody/tr/td/div</value>
      <webElementGuid>53c87f10-9516-446b-acee-2c9765323ba9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Size'])[1]/following::div[1]</value>
      <webElementGuid>029948bb-a2c8-4aa7-b53d-818433a8e60d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Last modified'])[2]/following::div[1]</value>
      <webElementGuid>82e5a3b1-ab6d-4432-84e4-4838b0a24221</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='May 21, 2024'])[1]/preceding::div[3]</value>
      <webElementGuid>3bdf71cf-16d6-4646-9e75-ab13f7223a70</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//td/div</value>
      <webElementGuid>21deed41-51db-408c-8c8b-0d78e7cc9d90</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = 'State Bank Collect (onlinesbi.sbi) Link.docx' or . = 'State Bank Collect (onlinesbi.sbi) Link.docx')]</value>
      <webElementGuid>4d7bac21-215b-4417-bbf9-e0d855c7020a</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
